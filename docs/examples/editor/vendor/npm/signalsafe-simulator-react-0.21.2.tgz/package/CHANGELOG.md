# Changelog

## 0.21.2 — prepared 2026-11-10

- Unify authored call rendering and navigation, preserving unknown dates, voicemail actions and related history.
- Keep browser navigation, stable page IDs and authored page content synchronized.
- Initialize mailbox folder/compose routes and preserve custom folders and unknown dates.
- Refresh selected photo details through the record store, including paged records, while preserving unsaved edits.
- Synchronize externally selected Vault entries and message previews without changing saved starting positions.

Prepared source version; npm publication and downstream registry-lock refresh are separate steps.

## [0.21.1] - Release approved 2026-10-21

Includes the verified shared frame and accessibility fixes, regional input and navigation quality fixes, and the default-theme pairing contract. Depends on core `0.7.1`. The optional default-theme peer is `^0.13.1`; custom or unstyled integrations remain supported without installing this theme.

## 0.21.0 — October 7, 2026

- Add the shared contact editor: `views/contacts/ContactEditorForm` (controlled form with `createId`, `identityImage`, `identityExtras` and `addressFields` slots), `ContactEditorScreen` (page frame with title and notices), `ContactDetailActions` (Edit and Delete icon buttons) and the pure `contactFormModel` helpers. `PhoneContactEditor` now localizes its Back label with `app.back`.
- Add shared call-history composition: `views/phone/PhoneHistoryLayout` (header, list, detail and host content), `PhoneHistoryCallButton` and `PhoneHistorySummaryTitle`. `PhoneHistoryScreen` is rebuilt on the layout, and the call details heading reads "Calls with ..." or "N calls from this number" using `calls.with` and the new plural keys `calls.fromNumber.one` and `calls.fromNumber.other`.
- Add `plain` to `DevicePage` and the `SIM_APP_PAGE_CONTENT_PLAIN` class for pages that supply their own padding.
- Photos: add an "Add photo" item to the app navigation that opens the file picker, format map coordinates with four decimals (`apps/photos/formatCoordinate`).
- Add shared Home clock (`apps/home/HomeClock`), regional settings (`apps/settings/RegionalSettings`, `regionalFormats`, `contract/regionalPresentation`), device backup (`apps/settings/DeviceBackup`, `parseBackup`), scenario mail source, SMS timeline paging, attachment and scroll helpers, and photo capture-date helpers, with new subpath exports for each.
- Require core 0.7.0 (optional `duration_seconds` on call entries).
- Move `MIGRATION.md` and `RELEASING.md` into `docs/` and `examples/` into `docs/examples/`; the docs ship in the package and the examples do not.

## 0.20.2 — October 5, 2026

- Fix `LoadMore` re-creating its `IntersectionObserver` whenever `count` changed, which requested another page immediately while the sentinel was still visible. Automatic loading again requests once per visibility transition. `count` is exposed as `data-loaded-count`. Use 0.20.2 instead of 0.20.0 and 0.20.1.

## 0.20.1 — October 4, 2026

- Fix `resolveScreenOverride` throwing when `state.view.activeApp` is not a known app, as 0.20.0 did for malformed state from untyped hosts. Unknown apps again resolve no override. Use 0.20.1 instead of 0.20.0.

## 0.20.0 — October 4, 2026

- Enforce 100% statement, branch, function and line coverage in CI, with jsdom tests for the browser, lock, mail, photos and vault apps.
- Make `PhoneCallView` `onMute` and `onDigit` optional; they are only used while a call is connected.
- Remove unreachable guards (disabled controls already prevent them) and tighten keyboard app switching to exact `Alt+1`–`Alt+5` keys.
- Split `SimulatorAppsHost` into `SimulatorAppsPresentation`, `SimulatorAppsAssets`, `SimulatorAppsLock` and `SimulatorAppsPlatform`; the host contract is unchanged.
- Add `formatCaptureDate(metadata, translate?)`: the default label now comes from the English catalog and follows the active locale when a translator is passed.
- Compose `SimulatorWithSessionProps`, `ContactsViewProps` and `PhoneCallViewProps` from role interfaces, exported as `contract/sessionHostProps`, `views/contacts/contactsViewRoles` and `views/phone/phoneCallViewRoles`. Props are unchanged.
- Give each `ScreenEntry` a `render` function so the registry renders without a cast.
- Forward native attributes from `SimulatorSearchInput` and `SimulatorAvatar`.
- Add catalog keys `app.photos.captureDate`, `app.photos.captureUnknown`, `app.photos.captureZoneUnknown`, `screen.phoneCallView.dial.digit` and `screen.smsSimulatorView.link`.
- Route clock and document access through `utils/browser/browserEnvironment` (`currentIsoTime`, `currentTimeMs`, `listenForDocumentKeydown`, `dispatchDocumentEvent`, `focusDocumentElement`).
- Check import cycles and duplicated code in CI (`check:cycles`, `check:duplication`).
- Use core's `ReplyKind` constant instead of a local type; the values are unchanged.
- Split long components and wide hooks (photos, SMS thread links, diagnostics band, vault and mail navigation, developer controls) without changing behavior.
- Require core 0.6.0. See MIGRATION.md.

## 0.19.1 — October 4, 2026

The 0.19.0 tag failed the packed-runtime gate on stale subpaths and was not published; its tag is retained unchanged.

- Group `utils` into `navigation`, `payload`, `preview`, `telemetry` and `lists`, `views` by app, and class-name modules under `ui/styles`. Public subpaths moved with them; see MIGRATION.md.
- Replace repeated string literals with typed constants (`SimulatorActionType`, `SimulatorEventKind`, `SimulatorChannel` usage, `BrowserLayout`, `CallHistoryEntryKind`, `SimulatorLintCode`, tones, presets and others), shared class-name constants, and English catalog keys for device-app text.
- Simplify large components into shared modules (`AppSecondaryNav`, `DevicePage`, `CollapsibleReport`, stable keys, text matching, browser field type) without changing behavior.
- Require core 0.5.0.

## 0.19.0-cleanup.4 (local, unpublished)

Remove legacy conversion, wire and presentation aliases; migrate consumers to canonical contracts. See MIGRATION.md.

## 0.18.0-ui.4 (local)

- Add an identity-content slot to PhoneContactEditor so hosts reuse its form and action controls with structured names and photo inputs.

## Unreleased — shared PhoneMe UI

- Use one shared call view, avatar/navigation primitives, and full-width history-row presentation across scenario and provider hosts.
- Move the default PhoneMe palette and screen layout into the theme package; preserve host data, callbacks, and explicit appearance configuration.
- Verify narrow devices and enlarged text, and prevent duplicate message actions when shell navigation renders them.
- Local `ui` prereleases are packed integration artifacts, not registry releases.

## 0.17.0 — September 29, 2026

- Export reusable Vault, Photos/editor/location, lock/settings, mutable Mailbox and HTML/React browser screens, page hooks and browser/file helpers.
- Add `SimulatorAppsProvider` for host formatting, notes editing, map rendering, file/metadata and lock adapters. Default notes use a plain textarea; external maps require an explicit host renderer.
- Add mailbox source slots and display adapters without importing host storage or import services.
- Add optional `photo`, `numberLabel` and `description` to `PhoneHistoryDetail`; media and number labels render inside the card body. Existing supplied descriptions still render.
- Require core 0.4.1; retain React 18 peers and add Lucide icons.

- Compile and execute the repository examples against the packed public API during package smoke checks.

## [Unreleased]

### Changed

- Require a matching GitHub version tag for npm publication; branch workflow runs only validate.

## [0.16.3] - 2026-09-16

### Changed

- Require simulator-core 0.3.2 and retain TreeSpec ^0.4.1.
- Include navigation quality fixes and additional runtime, payload, and host-interaction regression tests.

- Lower the runtime requirement to Node >=19.0.0 and refresh the TreeSpec lockfile to 0.4.1.
- Add isolated packed-consumer tests on Node 19.0.0 and Node 19–24; retain modern tooling checks on Node 22/24.

## 0.16.2 — 2026-09-16

- Refresh release tooling to Vitest 5; preserve React 18 compatibility.
- Add localized semantic page/list-group, contact-value and photo controls with default accessible SVG photo actions.
- Add controlled email/message/dial drafts, explicit action capabilities, selection-aware keypad editing and grouped contact fields.
- Preserve host navigation interception, screen overrides, readonly datasource snapshots and React 18 compatibility.
- Require simulator-core 0.3.1 and refresh TreeSpec dependencies; use standalone registry lockfiles.

## 0.4.0 — 2026-09-11

- Expose deeply readonly datasource snapshots, matching recursive runtime freezing. Nested writes now fail at compile time; use the existing mutable session conversion when editing content.
- Add `updateSimulatorPayload` to reconcile a previously converted payload without cloning content again.
- Compile negative public type checks alongside source checks and verify mutable-copy isolation.

## 0.3.0 — 2026-09-11

- Add validated JSON datasource snapshots sharing the existing full-device/session model.
- Add optional controlled call, keypad, contact editor, history detail/pagination and Home tile components.
- Include reviewed navigation contracts, screen overrides, accessible compose controls and semantic presentation/history hooks previously consumed by PhoneMe as local prereleases.
- Keep React 18 peers and provider-free scenario behavior; typecheck against declared packages without sibling source aliases.

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.11] - 2026-08-28

### Changed

- Require published `@signalsafe/simulator-core` **^0.1.10** and `@signalsafe/tree-spec` **^0.3.4**.

## [0.2.10] - 2026-08-28

### Changed

- Updated the TypeScript 7-compatible build configuration and current CI action dependencies.

### Notes

- No public React component API changes.

## [0.2.9] - 2026-07-02

### Changed

- Re-export canonical device payload types from `@signalsafe/simulator-core` in `portableSimulator.ts` instead of duplicating definitions in `@signalsafe/simulator-react`.
- Bumped `@signalsafe/simulator-core` dependency to `^0.1.8`.

### Added

- Tests asserting portable payload re-exports align with `@signalsafe/simulator-core` guards.

### Notes

- Additive compatibility release — existing `@signalsafe/simulator-react` import paths for payload types remain valid.
- Required by `@signalsafe/simulator-device@0.3.3` and DeliveryPlus registry pins.

## [0.2.4] - 2026-06-28

### Added

- Optional `hostOwnsPhoneContactDetail` and `onPhoneContactOpen` on `SimulatorWithSession` so hosts can render their own phone contact detail screen without DOM scraping.
- Exported `SimulatorPhoneContactOpenProps` type from the package barrel.
- Tests and docs for host-owned contact detail behavior.

### Notes

- Additive release only — default contact row behavior is unchanged when `hostOwnsPhoneContactDetail` is omitted or false.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.3] - 2026-06-30

### Added

- Optional `renderIncomingCallExtra` slot on `SimulatorWithSession` for host content below incoming-call Answer/Ignore actions.
- Semantic wrapper classes `simulator-phone__incoming-call-extra` and `simulator-phone__incoming-call-after-actions`.
- Exported `SimulatorPhoneIncomingCallExtraRenderProps` type from the package barrel.
- Tests and docs for the incoming-call extension point.

### Notes

- Additive release only — existing screens render unchanged when the slot is omitted.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.2] - 2026-06-29

### Added

- Stable semantic view class hooks (`simulator-runtime`, `simulator-phone`, `simulator-email`, `simulator-messages`, channel modifiers, dialer call button, contact rows, inbox rows, thread list/detail, etc.) for host CSS and tests without DOM enhancers.
- Tests asserting semantic classes render on key simulator views.
- README and `docs/UI_KIT_AGNOSTIC_USAGE.md` styling contract for semantic hooks.

### Notes

- Additive release only — no public React component API changes.
- No Bootstrap, Material, or ThemeProvider dependencies were added.
- `@signalsafe/simulator-core` dependency unchanged.

## [0.2.1] - 2026-06-28

### Fixed

- Restored `@signalsafe/simulator-core` as a runtime dependency of `@signalsafe/simulator-react`.

### Notes

- No public React component API changes.
- No Bootstrap or UI framework dependencies were added.
- React and React DOM remain peer dependencies.

## [0.2.0] - 2026-06-28

### Changed

- Removed Bootstrap-specific runtime styling assumptions from the React simulator components.
- Replaced Bootstrap class coupling with UI-kit-agnostic `simulator-*` class hooks.
- Updated internal SignalSafe dependency ranges for the current package release line:
    - `@signalsafe/tree-spec@^0.3.3`
    - `@signalsafe/simulator-core@^0.1.7`
- Raised the supported Node.js baseline to Node 22.12+.

### Added

- Added learner-safe error rendering defaults.
- Added `showDiagnostics` support for author, admin, and QA surfaces.
- Added tests covering sanitized error output and unsupported-state rendering.
- Added package smoke checks for the built and packed artifact.

### Fixed

- Addressed SonarCloud findings in `src/ui/primitives.tsx`: mark component props as read-only, move clickable list-row handlers onto an inner `<button>` for keyboard accessibility, and use `export…from` for class-token re-exports.
- Added `simulator-list__item-button` class hook for host styling of clickable list rows.

### Notes

- This release does not include `react-bootstrap` or `bootstrap`.
- Host applications are responsible for styling the emitted `simulator-*` hooks.
- Learner-facing screens should keep diagnostics disabled by default.
- Diagnostics should only be enabled in trusted authoring, admin, development, or QA contexts.

## [0.1.6] - 2026-06-26

### Fixed

- Clear monorepo `paths` from standalone `tsconfig.build.json` so local `yarn build` works outside the monorepo.

### Changed

- Standardize development on Yarn 1.22.22 (`packageManager`, README dev commands).
- Bump `@signalsafe/simulator-core` to `^0.1.5` and `@signalsafe/tree-spec` to `^0.3.2`.

## [0.1.5] - 2026-06-26

### Added

- `SECURITY.md`, Dependabot, `CHANGELOG.md`, updated [RELEASING.md](./RELEASING.md).
- Expanded React package test coverage.
- Package artifact smoke test (`yarn smoke:package`).

### Changed

- Package metadata and README (Batches 3–4).

### CI

- Checks and tests on every PR; Sonar **`scan`** is label-gated on PRs and runs on tag push and manual dispatch (Batch 1).
- Publish only from manual **`main`** dispatch or **`v*`** tags (not PR labels); publish requires **`checks`**, **`tests`**, and **`scan`**.

[Unreleased]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.11...HEAD
[0.2.11]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.10...v0.2.11
[0.2.10]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.9...v0.2.10
[0.2.3]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/SignalSafeSoftware/simulator-react/compare/v0.1.6...v0.2.0
[0.1.6]: https://github.com/SignalSafeSoftware/simulator-react/releases/tag/v0.1.6
[0.1.5]: https://github.com/SignalSafeSoftware/simulator-react/releases/tag/v0.1.5
