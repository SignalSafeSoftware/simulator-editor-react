# Changelog

## 0.21.3 — prepared 2026-11-10

- Own default mailbox route initialization and email selection callbacks so hosts need no duplicate mailbox composition.
- Load authored starting targets through the shared store, including photos and Vault folders/entries.
- Synchronize appearance settings when authored values change while retaining unapplied local edits on unrelated renders.
- Preserve unified call history, contact routing and scenario Home widgets.
- Retain the merged public email-layout/demo lock fixes.

Prepared source version; npm publication and downstream registry-lock refresh are separate steps.

## 0.21.2 — release approved 2026-10-21

- Adopt exact simulator-theme-bootstrap 0.13.2 for the shared email layout fix.
- Rebuild the gallery with the same theme; update the portable demo only after the new Device version is public.
- Preserve device runtime/declarations and public exports unchanged.


## [0.21.1] - Release approved 2026-10-21

Publication now waits for the existing hosted Sonar scan; the matching-tag-only publication condition is unchanged.

Composes core `0.7.1`, React `0.21.1` and theme `0.13.1` through exact dependencies. Preserves the shared screens, gallery and portable demo, including the separate demo dependency lock and patched Zod closure.

## 0.21.0 — October 7, 2026

- Require simulator-react 0.21.0, core 0.7.0 and theme 0.13.0.
- Format incoming-call history times with the host's regional preferences instead of showing the raw timestamp.
- Add the shared Settings page (`apps/SimulatorDeviceSettings`) with Appearance, Region and formats, and Screen password sections; extend the synthetic UI gallery with these screens and the shared contact editor.
- Route call history, call details and the contact editor through the shared simulator-react components used by PhoneMe.
- Demo (`docs/examples/local-apps`): use real sample photos with capture dates and locations, add, edit and delete contacts with the shared editor, show the shared Home clock, and deploy to GitHub Pages with the `Simulator demo` workflow. Browser tests cover contacts, data, messages, thread scrolling, layout and the demo screens.
- Move `MIGRATION.md`, `RELEASING.md` and `examples/` into `docs/` (`docs/examples/local-apps`), still shipped in the package.

## 0.20.1 — October 5, 2026

- Require simulator-react 0.20.2, which fixes `LoadMore` requesting an extra page when the loaded count changes, and 0.20.1's malformed-active-app fix. Use 0.20.1 instead of 0.20.0.

## 0.20.0 — October 4, 2026

- Require simulator-react 0.20.1, core 0.6.0 and theme 0.12.1.
- Extract contact-list focus restoration from `SimulatorPhoneDevice` and share the secondary-menu item mapping; behavior is unchanged.
- Check import cycles and duplicated code in CI (`check:cycles`, `check:duplication`).
- Align lint and format tooling with core and react and update development dependencies.

## 0.19.0 — October 4, 2026

- Group source into `phone`, `apps` and `runtime`; public subpaths moved with it. See MIGRATION.md.
- Use shared constants for device kind, contact detail mode and shell host kind, and localized text keys from simulator-react.
- Require simulator-react 0.19.1, core 0.5.0 and theme 0.12.0.

## 0.19.0-cleanup.5 (local, unpublished)

Remove legacy conversion, wire and presentation aliases; migrate consumers to canonical contracts. See MIGRATION.md.

## Unreleased — shared PhoneMe UI

- Use one shared call view, avatar/navigation primitives, and full-width history-row presentation across scenario and provider hosts.
- Move the default PhoneMe palette and screen layout into the theme package; preserve host data, callbacks, and explicit appearance configuration.
- Verify narrow devices and enlarged text, and prevent duplicate message actions when shell navigation renders them.
- Local `ui` prereleases are packed integration artifacts, not registry releases.

## 0.17.0 — September 29, 2026

- Export `SimulatorDeviceApps`, `SimulatorDeviceAppsProvider` and `SimulatorCallBoundary` for Home, local apps, locking and call overlays that preserve mounted drafts.
- Delegate app navigation items to the shared React primitive while preserving existing device CSS hooks.
- Include a strict React 18 example with an in-memory host adapter and browser workflow test, importing only public package APIs.
- Require core 0.4.1 and React 0.17.0; retain React 18 peers. Theme 0.10.0 is used by the gallery/example.

## [Unreleased]

### Changed

- Address supplied SonarCloud findings in navigation, contact editing, gallery contexts, accessibility, and package verification.
- Disable install-time lifecycle scripts in CI; build the gallery explicitly before packing.
- Preserve contact row identity and focus while editing or removing earlier rows.

- Require a matching GitHub version tag for npm publication; branch workflow runs only validate.

## [0.16.3] - 2026-09-16

### Changed

- Require simulator-core 0.3.2 and simulator-react 0.16.3; validate published dependencies in the Node runtime matrix.
- Expand device behavior and edge-case coverage and enforce 100% statements, branches, functions, and lines.
- Simplify redundant internal fallbacks and resolve selected contacts before deriving their host mode.

- Lower the runtime requirement to Node >=19.0.0 and refresh the TreeSpec lockfile to 0.4.1.
- Add isolated packed-consumer tests on Node 19.0.0 and Node 19–24; retain modern tooling checks on Node 22/24.

## 0.16.2 — 2026-09-16

- Refresh release tooling to Vitest 5, Vite 8, TypeScript 7, jsdom 30 and current Testing Library patches; preserve React 18 compatibility.
- Adopt simulator-react 0.16.2 and simulator-core 0.3.1.
- Compose controlled drafts and action capabilities; support labeled contact values and asynchronous contact edits.
- Add controlled appearance settings with local raster preview and host-owned persistence.
- Ship a rebuilt synthetic gallery covering contact, call, message and email states, built from declared registry dependencies without sibling source aliases.

## 0.5.0 — 2026-09-11

- Adopt simulator-react 0.4 deeply readonly datasource contracts.
- Convert datasource content once per replacement; reconcile navigation without repeated full-payload clones.
- Remove the redundant clone/freeze round trip from tolerant legacy JSON conversion.
- Preserve JSON behavior, datasource refresh navigation and mounted contact drafts.

## 0.4.0 — 2026-09-11

- Add optional datasource composition and refresh behavior while retaining legacy JSON value consumers.
- Depend on simulator-react ^0.3.0; keep React 18 compatibility.
- Include reviewed portable navigation, Settings and contact composition previously adopted through PhoneMe local prereleases.
- Verify equivalent JSON/datasource rendering across calls, contacts, SMS and email, and preservation of contact drafts on refresh.
